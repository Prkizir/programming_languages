COMPILE

javac Battle.java

RUN

java Battle

*note: you can change the number of drones and riders within the code by chaning the values of "dnum" and "rnum" respectively.
